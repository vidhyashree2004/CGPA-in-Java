import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner Sc=new Scanner(System.in);
	    int studentcgpa=Sc.nextInt();
	    switch (studentcgpa){
	    case 10:
	    System.out.println("CGPA 10 you are outstanding");
	    break;
	    case 9:
	    System.out.println("CGPA 9 you are excelling");
	    break;
	    default:
	    System.out.println("CGPA 8 less you are progressing");
	    break;
	}
	        
	}
	
	}
